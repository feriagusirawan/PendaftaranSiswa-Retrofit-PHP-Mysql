package com.sirzechs.ppdb;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import com.sirzechs.ppdb.api.ApiClient;
import com.sirzechs.ppdb.api.ApiInterface;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    Button btnPengumuman, btnPetunjuk;
    ImageButton btnKirim, btnPaud, btnSd, btnStatus;
    TextView etKode_Pendaftar, etUsername, etEmail, etCardUser, etTvid, etLihatId;
    SessionManager sessionManager;
    String KodePendaftar, Username, Email, Id, KDDaf;
    ApiInterface apiInterface;
    String KodePendaftaran, Kode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        sessionManager = new SessionManager(MainActivity.this);

        if (!sessionManager.isLoggedIn()) {
            moveToLogin();
        }

        etTvid = findViewById(R.id.tvId);
        etUsername = findViewById(R.id.tvUsername);
        etKode_Pendaftar = findViewById(R.id.tvKodePendaftaran);
        etEmail = findViewById(R.id.tvEmail);

        Id = sessionManager.getUserDetail().get(SessionManager.USER_ID);
        Username = sessionManager.getUserDetail().get(SessionManager.USERNAME);
        Email = sessionManager.getUserDetail().get(SessionManager.EMAIL);
        KodePendaftar = sessionManager.getUserDetail().get(SessionManager.KODE_PENDAFTAR);


        etTvid.setText(Id);
        etUsername.setText(Username);
        etEmail.setText(Email);
        etKode_Pendaftar.setText(KodePendaftar);




        btnPaud = findViewById(R.id.btnPaud);
        btnPaud.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, PaudTkActivity.class);
                startActivity(intent);
            }
        });

        btnSd = findViewById(R.id.btnSd);
        btnSd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, SdActivity.class);
                startActivity(intent);
            }
        });

        btnKirim = findViewById(R.id.btnDaftar);
        btnKirim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, DataActivity.class);
                startActivity(intent);
            }
        });

        btnKirim = findViewById(R.id.btnDaftarSiswa);
        btnKirim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, DataSiswaActivity.class);
                startActivity(intent);
            }
        });

    }

    private void moveToLogin() {
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NO_HISTORY);
        startActivity(intent);
        finish();
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.actionLogout:
                sessionManager.logoutSession();
                moveToLogin();
        }
        return super.onOptionsItemSelected(item);
    }

}