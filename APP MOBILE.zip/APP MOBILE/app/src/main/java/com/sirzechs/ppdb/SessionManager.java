package com.sirzechs.ppdb;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.sirzechs.ppdb.model.data.DataData;
import com.sirzechs.ppdb.model.login.LoginData;

import java.util.HashMap;

public class SessionManager {
    private Context _context;
    private SharedPreferences sharedPreferences;
    private SharedPreferences.Editor editor;

    // Response Login

    public static final String IS_LOGGED_IN = "isLoggedIn";
    public static final String USER_ID = "id_admin";
    public static final String USERNAME = "username";
    public static final String EMAIL = "email";
    public static final String KODE_PENDAFTAR = "kode_pendaftar";
    public static final String ROLE = "role";


    // Response Data
    public static final String DATA_KODE_PENDAFTAR = "kode_pendaftar";
    public static final String DATA_TAHUN_AJARAN = "tahun_ajaran";
    public static final String DATA_NAMA_LENGKAP = "nama_lengkap";
    public static final String DATA_TEMPAT_LAHIR ="tempat_lahir";
    public static final String DATA_TANGGAL_LAHIR = "tanggal_lahir";
    public static final String DATA_JENIS_KELAMIN = "jenis_kelamin";
    public static final String DATA_NO_NIK = "no_nik";
    public static final String DATA_AGAMA = "agama";
    public static final String DATA_SUKU = "suku";
    public static final String DATA_ANAK_KE = "anak_ke";

    public static final String DATA_NAMA_AYAH_KANDUNG = "nama_ayah_kandung";
    public static final String DATA_TTL_AYAH = "ttl_ayah";
    public static final String DATA_NO_TELP_AYAH = "no_telp_ayah";
    public static final String DATA_PEKERJAAN_AYAH = "pekerjaan_ayah";
    public static final String DATA_ALAMAT_AYAH = "alamat_ayah";

    public static final String DATA_NAMA_IBU_KANDUNG = "nama_ibu_kandung";
    public static final String DATA_TTL_IBU = "ttl_ibu";
    public static final String DATA_NO_TELP_IBU = "no_telp_ibu";
    public static final String DATA_PEKERJAAN_IBU = "pekerjaan_ibu";
    public static final String DATA_ALAMAT_IBU = "alamat_ibu";

    public static final String DATA_NO_KIP = "no_kip";
    public static final String DATA_TINGKAT_YANG_DIMASUKI = "tingkat_yang_dimasuki";
    public static final String DATA_TANGGAL_DAFTAR = "tanggal_daftar";




    // Response Status

    public static final String STA_KODE_PENDAFTAR = "kode_pendaftar";


    public SessionManager (Context context){
        this._context = context;
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        editor = sharedPreferences.edit();
    }

    public void createLoginSession(LoginData user){
        editor.putBoolean(IS_LOGGED_IN, true);
        editor.putString(USER_ID, user.getId_admin());
        editor.putString(USERNAME, user.getUsername());
        editor.putString(EMAIL, user.getEmail());
        editor.putString(ROLE, user.getRole());
        editor.putString(KODE_PENDAFTAR, user.getKode_pendaftar());
        editor.commit();
    }

    public HashMap<String,String> getUserDetail(){
        HashMap<String,String> user = new HashMap<>();
        user.put(USER_ID, sharedPreferences.getString(USER_ID,null));
        user.put(USERNAME, sharedPreferences.getString(USERNAME,null));
        user.put(EMAIL, sharedPreferences.getString(EMAIL,null));
        user.put(KODE_PENDAFTAR, sharedPreferences.getString(KODE_PENDAFTAR,null));
        user.put(ROLE, sharedPreferences.getString(ROLE,null));
        return user;
    }

    public void logoutSession(){
        editor.clear();
        editor.commit();
    }

    public boolean isLoggedIn(){
        return sharedPreferences.getBoolean(IS_LOGGED_IN, false);
    }

    public void createDataSession(DataData data) {

        editor.putString(DATA_KODE_PENDAFTAR, data.getKode_pendaftar());
        editor.putString(DATA_TAHUN_AJARAN, data.getTahun_ajaran());
        editor.putString(DATA_NAMA_LENGKAP, data.getNama_lengkap());
        editor.putString(DATA_TEMPAT_LAHIR, data.getTempat_lahir());
        editor.putString(DATA_TANGGAL_LAHIR, data.getTanggal_lahir());
        editor.putString(DATA_JENIS_KELAMIN, data.getJenis_kelamin());
        editor.putString(DATA_NO_NIK, data.getNo_nik());
        editor.putString(DATA_AGAMA, data.getAgama());
        editor.putString(DATA_SUKU, data.getSuku());
        editor.putString(DATA_ANAK_KE, data.getAnak_ke());

        editor.putString(DATA_NAMA_AYAH_KANDUNG, data.getNama_ayah_kandung());
        editor.putString(DATA_TTL_AYAH, data.getTtl_ayah());
        editor.putString(DATA_NO_TELP_AYAH, data.getNo_telp_ayah());
        editor.putString(DATA_PEKERJAAN_AYAH, data.getPekerjaan_ayah());
        editor.putString(DATA_ALAMAT_AYAH, data.getAlamat_ayah());

        editor.putString(DATA_NAMA_IBU_KANDUNG, data.getNama_ibu_kandung());
        editor.putString(DATA_TTL_IBU, data.getTtl_ibu());
        editor.putString(DATA_NO_TELP_IBU, data.getNo_telp_ibu());
        editor.putString(DATA_PEKERJAAN_IBU, data.getPekerjaan_ibu());
        editor.putString(DATA_ALAMAT_IBU, data.getAlamat_ibu());

        editor.putString(DATA_NO_KIP, data.getNo_kip());
        editor.putString(DATA_TINGKAT_YANG_DIMASUKI, data.getTingkat_yang_dimasuki());
        editor.putString(DATA_TANGGAL_DAFTAR, data.getTanggal_daftar());

        editor.commit();
    }

    public HashMap<String, String> getDataDetail(){
        HashMap<String,String> data = new HashMap<>();
        data.put(DATA_KODE_PENDAFTAR, sharedPreferences.getString(DATA_KODE_PENDAFTAR, null));
        data.put(DATA_TAHUN_AJARAN, sharedPreferences.getString(DATA_TAHUN_AJARAN, null));
        data.put(DATA_NAMA_LENGKAP, sharedPreferences.getString(DATA_NAMA_LENGKAP, null));
        data.put(DATA_TEMPAT_LAHIR, sharedPreferences.getString(DATA_TEMPAT_LAHIR, null));
        data.put(DATA_TANGGAL_LAHIR, sharedPreferences.getString(DATA_TANGGAL_LAHIR, null));
        data.put(DATA_JENIS_KELAMIN, sharedPreferences.getString(DATA_JENIS_KELAMIN, null));
        data.put(DATA_NO_NIK, sharedPreferences.getString(DATA_NO_NIK, null));
        data.put(DATA_AGAMA, sharedPreferences.getString(DATA_AGAMA, null));
        data.put(DATA_SUKU, sharedPreferences.getString(DATA_SUKU, null));
        data.put(DATA_ANAK_KE, sharedPreferences.getString(DATA_ANAK_KE, null));

        data.put(DATA_NAMA_AYAH_KANDUNG, sharedPreferences.getString(DATA_NAMA_AYAH_KANDUNG, null));
        data.put(DATA_TTL_AYAH, sharedPreferences.getString(DATA_TTL_AYAH, null));
        data.put(DATA_NO_TELP_AYAH, sharedPreferences.getString(DATA_NO_TELP_AYAH, null));
        data.put(DATA_PEKERJAAN_AYAH, sharedPreferences.getString(DATA_PEKERJAAN_AYAH, null));
        data.put(DATA_ALAMAT_AYAH, sharedPreferences.getString(DATA_ALAMAT_AYAH, null));


        data.put(DATA_NAMA_IBU_KANDUNG, sharedPreferences.getString(DATA_NAMA_IBU_KANDUNG, null));
        data.put(DATA_TTL_IBU, sharedPreferences.getString(DATA_TTL_IBU, null));
        data.put(DATA_NO_TELP_IBU, sharedPreferences.getString(DATA_NO_TELP_IBU, null));
        data.put(DATA_PEKERJAAN_IBU, sharedPreferences.getString(DATA_PEKERJAAN_IBU, null));
        data.put(DATA_ALAMAT_IBU, sharedPreferences.getString(DATA_ALAMAT_IBU, null));

        data.put(DATA_NO_KIP, sharedPreferences.getString(DATA_NO_KIP, null));
        data.put(DATA_TINGKAT_YANG_DIMASUKI, sharedPreferences.getString(DATA_TINGKAT_YANG_DIMASUKI, null));
        data.put(DATA_TANGGAL_DAFTAR, sharedPreferences.getString(DATA_TANGGAL_DAFTAR, null));


        return data;
    }

    public HashMap<String, String> getStatusDetail(){
        HashMap<String,String> data = new HashMap<>();
        data.put(STA_KODE_PENDAFTAR, sharedPreferences.getString(STA_KODE_PENDAFTAR, null));
        return data;
    }
}