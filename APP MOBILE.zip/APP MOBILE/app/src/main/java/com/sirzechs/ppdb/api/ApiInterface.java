package com.sirzechs.ppdb.api;

import com.sirzechs.ppdb.model.data.Data;
import com.sirzechs.ppdb.model.login.Login;
import com.sirzechs.ppdb.model.register.Register;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface ApiInterface {
    @FormUrlEncoded
    @POST("login.php")
    Call<Login> loginResponse(
            @Field("email") String email,
            @Field("password") String password
    );

    @FormUrlEncoded
    @POST("register.php")
    Call<Register> registerResponse(
            @Field("username") String username,
            @Field("email") String email,
            @Field("password") String password
    );
    @FormUrlEncoded
    @POST("data.php")
    Call<Data> dataResponse(
            @Field("kode_pendaftar") String kode_pendaftar,
            @Field("tahun_ajaran") String tahun_ajaran,
            @Field("nama_lengkap") String nama_lengkap,
            @Field("tempat_lahir") String tempat_lahir,
            @Field("tanggal_lahir") String tanggal_lahir,
            @Field("jenis_kelamin") String jenis_kelamin,
            @Field("no_nik") String no_nik,
            @Field("agama") String agama,
            @Field("suku") String suku,
            @Field("anak_ke") String anak_ke,
            @Field("nama_ayah_kandung") String nama_ayah_kandung,
            @Field("ttl_ayah") String ttl_ayah,
            @Field("no_telp_ayah") String no_telp_ayah,
            @Field("pekerjaan_ayah") String pekerjaan_ayah,
            @Field("alamat_ayah") String alamat_ayah,
            @Field("nama_ibu_kandung") String nama_ibu_kandung,
            @Field("ttl_ibu") String ttl_ibu,
            @Field("no_telp_ibu") String no_telp_ibu,
            @Field("pekerjaan_ibu") String pekerjaan_ibu,
            @Field("alamat_ibu") String alamat_ibu,
            @Field("no_kip") String no_kip,
            @Field("tingkat_yang_dimasuki") String tingkat_yang_dimasuki,
            @Field("tanggal_daftar") String tanggal_daftar

    );
}