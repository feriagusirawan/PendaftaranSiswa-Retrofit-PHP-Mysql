package com.sirzechs.ppdb.model.data;

import com.google.gson.annotations.SerializedName;

public class DataData {

    @SerializedName("kode_pendaftar")
    private String kode_pendaftar;

    @SerializedName("tahun_ajaran")
    private String tahun_ajaran;

    @SerializedName("nama_lengkap")
    private String nama_lengkap;

    @SerializedName("tempat_lahir")
    private String tempat_lahir;

    @SerializedName("tanggal_lahir")
    private String tanggal_lahir;

    @SerializedName("jenis_kelamin")
    private String jenis_kelamin;

    @SerializedName("no_nik")
    private String no_nik;

    @SerializedName("agama")
    private String agama;

    @SerializedName("suku")
    private String suku;

    @SerializedName("anak_ke")
    private String anak_ke;

    @SerializedName("nama_ayah_kandung")
    private String nama_ayah_kandung;

    @SerializedName("ttl_ayah")
    private String ttl_ayah;

    @SerializedName("no_telp_ayah")
    private String no_telp_ayah;

    @SerializedName("pekerjaan_ayah")
    private String pekerjaan_ayah;

    @SerializedName("alamat_ayah")
    private String alamat_ayah;

    @SerializedName("nama_ibu_kandung")
    private String nama_ibu_kandung;

    @SerializedName("ttl_ibu")
    private String ttl_ibu;

    @SerializedName("no_telp_ibu")
    private String no_telp_ibu;

    @SerializedName("pekerjaan_ibu")
    private String pekerjaan_ibu;

    @SerializedName("alamat_ibu")
    private String alamat_ibu;

    @SerializedName("no_kip")
    private String no_kip;

    @SerializedName("tingkat_yang_dimasuki")
    private String tingkat_yang_dimasuki;

    @SerializedName("tanggal_daftar")
    private String tanggal_daftar;


    public String getKode_pendaftar() {
        return kode_pendaftar;
    }

    public void setKode_pendaftar(String kode_pendaftar) {
        this.kode_pendaftar = kode_pendaftar;
    }

    public String getTahun_ajaran() {
        return tahun_ajaran;
    }

    public void setTahun_ajaran(String tahun_ajaran) {
        this.tahun_ajaran = tahun_ajaran;
    }


    public String getNama_lengkap() {
        return nama_lengkap;
    }

    public void setNama_lengkap(String nama_lengkap) {
        this.nama_lengkap = nama_lengkap;
    }


    public String getTempat_lahir() {
        return tempat_lahir;
    }

    public void setTempat_lahir(String tempat_lahir) {
        this.tempat_lahir = tempat_lahir;
    }


    public String getTanggal_lahir() {
        return tanggal_lahir;
    }

    public void setTanggal_lahir(String tanggal_lahir) {
        this.tanggal_lahir = tanggal_lahir;
    }


    public String getJenis_kelamin() {
        return jenis_kelamin;
    }

    public void setJenis_kelamin(String jenis_kelamin) {
        this.jenis_kelamin = jenis_kelamin;
    }


    public String getNo_nik() {
        return no_nik;
    }

    public void setNo_nik(String no_nik) {
        this.no_nik = no_nik;
    }


    public String getAgama() {
        return agama;
    }

    public void setAgama(String agama) {
        this.agama = agama;
    }


    public String getSuku() {
        return suku;
    }

    public void setSuku(String suku) {
        this.suku = suku;
    }

    public String getAnak_ke() {
        return anak_ke;
    }

    public void setAnak_ke(String anak_ke) {
        this.anak_ke = anak_ke;
    }

    public String getNama_ayah_kandung() {
        return nama_ayah_kandung;
    }

    public void setNama_ayah_kandung(String nama_ayah_kandung) {
        this.nama_ayah_kandung = nama_ayah_kandung;
    }

    public String getTtl_ayah() {
        return ttl_ayah;
    }

    public void setTtl_ayah(String ttl_ayah) {
        this.ttl_ayah = ttl_ayah;
    }

    public String getNo_telp_ayah() {
        return no_telp_ayah;
    }

    public void setNo_telp_ayah(String no_telp_ayah) {
        this.no_telp_ayah = no_telp_ayah;
    }

    public String getPekerjaan_ayah() {
        return pekerjaan_ayah;
    }

    public void setPekerjaan_ayah(String pekerjaan_ayah) {
        this.pekerjaan_ayah = pekerjaan_ayah;
    }

    public String getAlamat_ayah() {
        return alamat_ayah;
    }

    public void setAlamat_ayah(String alamat_ayah) {
        this.alamat_ayah = alamat_ayah;
    }



    public String getNama_ibu_kandung() {
        return nama_ibu_kandung;
    }

    public void setNama_ibu_kandung(String nama_ibu_kandung) {
        this.nama_ibu_kandung = nama_ibu_kandung;
    }

    public String getTtl_ibu() {
        return ttl_ibu;
    }

    public void setTtl_ibu(String ttl_ibu) {
        this.ttl_ibu = ttl_ibu;
    }

    public String getNo_telp_ibu() {
        return no_telp_ibu;
    }

    public void setNo_telp_ibu(String no_telp_ibu) {
        this.no_telp_ibu = no_telp_ibu;
    }

    public String getPekerjaan_ibu() {
        return pekerjaan_ibu;
    }

    public void setPekerjaan_ibu(String pekerjaan_ibu) {
        this.pekerjaan_ibu = pekerjaan_ibu;
    }

    public String getAlamat_ibu() {
        return alamat_ibu;
    }

    public void setAlamat_ibu(String alamat_ibu) {
        this.alamat_ibu = alamat_ibu;
    }
    public String getNo_kip() {
        return no_kip;
    }

    public void setNo_kip(String no_kip) {
        this.no_kip = no_kip;
    }

    public String getTingkat_yang_dimasuki() {
        return tingkat_yang_dimasuki;
    }

    public void setTingkat_yang_dimasuki(String tingkat_yang_dimasuki) {
        this.tingkat_yang_dimasuki = tingkat_yang_dimasuki;
    }

    public String getTanggal_daftar() {
        return tanggal_daftar;
    }

    public void setTanggal_daftar(String tanggal_daftar) {
        this.tanggal_daftar = tanggal_daftar;
    }
}
