package com.sirzechs.ppdb;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.sirzechs.ppdb.api.ApiClient;
import com.sirzechs.ppdb.api.ApiInterface;
import com.sirzechs.ppdb.model.data.Data;
import com.sirzechs.ppdb.model.data.DataData;

import java.util.Calendar;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DataActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener{
    SessionManager sessionManager;
    Spinner etTA, etJenisKelamin, etAgama, etTingkat;
    String KodePendaftar, EmailPendaftar, kode, ta, nama, tempatlahir, tanggallahir, jenis, nikakte, agama, suku, anakke, namaayah, ttlayah, notelpayah, pekerjaanayah, alamatayah, namaibu, ttlibu, notelpibu, pekerjaanibu, alamatibu, nokip, tingkat, tgldaftar;
    TextView tvTglLahir;
    Button btnKirim;
    EditText etKode,etNama, etTempatLahir, etNikAkte, etSuku, etAnakKe,etNamaAyah,etTtlAyah,etNoTelpAyah,etPekerjaanAyah,etAlamatAyah,etNamaIbu,etTtlIbu,etNoTelpIbu,etPekerjaanIbu,etAlamatIbu,etNoKIP,etTglDaftar;




    ApiInterface apiInterface;

    DatePickerDialog.OnDateSetListener setListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        sessionManager = new SessionManager(DataActivity.this);
        if(!sessionManager.isLoggedIn()){
            moveToLogin();
        }

        //deklarasi komponen
        btnKirim = findViewById(R.id.btnKirim);
        btnKirim.setOnClickListener(this);

        etKode = findViewById(R.id.etKode);
        etTA = findViewById(R.id.etTA);
        etNama = findViewById(R.id.etNama);
        etTempatLahir = findViewById(R.id.etTempatLahir);
  //      tv_Tgl_Lahir = findViewById(R.id.tv_Tgl_Lahir);

        etJenisKelamin = findViewById(R.id.etJenisKelamin);
        etNikAkte = findViewById(R.id.etNikAkte);
        etAgama = findViewById(R.id.etAgama);
        etSuku = findViewById(R.id.etSuku);
        etAnakKe = findViewById(R.id.etAnakKe);

        etNamaAyah = findViewById(R.id.etNamaAyah);
        etTtlAyah = findViewById(R.id.etTtlAyah);
        etNoTelpAyah = findViewById(R.id.etNoTelpAyah);
        etPekerjaanAyah = findViewById(R.id.etPekerjaanAyah);
        etAlamatAyah = findViewById(R.id.etAlamatAyah);

        etNamaIbu = findViewById(R.id.etNamaIbu);
        etTtlIbu = findViewById(R.id.etTtlIbu);
        etNoTelpIbu = findViewById(R.id.etNoTelpIbu);
        etPekerjaanIbu = findViewById(R.id.etPekerjaanIbu);
        etAlamatIbu = findViewById(R.id.etAlamatIbu);

        etNoKIP = findViewById(R.id.etNoKIP);
        etTingkat = findViewById(R.id.etTingkat);
        etTglDaftar = findViewById(R.id.etTglDaftar);


        //Tampilkan
        KodePendaftar = sessionManager.getUserDetail().get(SessionManager.KODE_PENDAFTAR);
        etKode.setText(KodePendaftar);

//        EmailPendaftar = sessionManager.getUserDetail().get(SessionManager.EMAIL);
//        etEmail.setText(EmailPendaftar);

        //spinner
        etTA = findViewById(R.id.etTA);
        Spinner spinnerta = findViewById(R.id.etTA);
        ArrayAdapter<CharSequence> adapterta = ArrayAdapter.createFromResource(this, R.array.tahunajaran, android.R.layout.simple_spinner_item);
        adapterta.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerta.setAdapter(adapterta);
        spinnerta.setOnItemSelectedListener(this);

        etJenisKelamin = findViewById(R.id.etJenisKelamin);
        Spinner spinnerjeniskelamin = findViewById(R.id.etJenisKelamin);
        ArrayAdapter<CharSequence> adapterjeniskelamin = ArrayAdapter.createFromResource(this, R.array.gender, android.R.layout.simple_spinner_item);
        adapterjeniskelamin.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerjeniskelamin.setAdapter(adapterjeniskelamin);
        spinnerjeniskelamin.setOnItemSelectedListener(this);

        etAgama = findViewById(R.id.etAgama);
        Spinner spinneragama = findViewById(R.id.etAgama);
        ArrayAdapter<CharSequence> adapteragama = ArrayAdapter.createFromResource(this, R.array.agama, android.R.layout.simple_spinner_item);
        adapteragama.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinneragama.setAdapter(adapteragama);
        spinneragama.setOnItemSelectedListener(this);

        etTingkat = findViewById(R.id.etTingkat);
        Spinner spinnertingkat = findViewById(R.id.etTingkat);
        ArrayAdapter<CharSequence> adaptertingkat = ArrayAdapter.createFromResource(this, R.array.tingkat, android.R.layout.simple_spinner_item);
        adaptertingkat.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnertingkat.setAdapter(adaptertingkat);
        spinnertingkat.setOnItemSelectedListener(this);




        //Date Picker
        Calendar calendar = Calendar.getInstance();
        final int defaultYear = calendar.get(Calendar.YEAR);
        final int defaultMonth = calendar.get(Calendar.MONTH);
        final int defaultDay = calendar.get(Calendar.DAY_OF_MONTH);

        tvTglLahir = findViewById(R.id.tv_Tgl_Lahir);
        tvTglLahir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        DataActivity.this, android.R.style.Theme_Holo_Dialog_MinWidth,
                        setListener, defaultYear, defaultMonth, defaultDay
                );
                datePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                datePickerDialog.show();
            }
        });


        setListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int selectedYear, int selectedMonth, int selectedDayOfMonth) {
                int month = selectedMonth + 1;
                String date = selectedDayOfMonth + "/" + month + "/" + selectedYear;
                tvTglLahir.setText(date);
            }
        };
    }



    private void moveToLogin() {
        Intent intent = new Intent(DataActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NO_HISTORY);
        startActivity(intent);
        finish();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.btnKirim:


                kode = etKode.getText().toString();

                //Spinner
                ta = etTA.getSelectedItem().toString();

                nama = etNama.getText().toString();
                tempatlahir = etTempatLahir.getText().toString();

                //textview
               tanggallahir = tvTglLahir.getText().toString();

               //spinner
               jenis = etJenisKelamin.getSelectedItem().toString();

                nikakte = etNikAkte.getText().toString();

                //spinner
                agama = etAgama.getSelectedItem().toString();

                suku = etSuku.getText().toString();
                anakke = etAnakKe.getText().toString();

                namaayah = etNamaAyah.getText().toString();
                ttlayah = etTtlAyah.getText().toString();
                notelpayah = etNoTelpAyah.getText().toString();
                pekerjaanayah = etPekerjaanAyah.getText().toString();
                alamatayah = etAlamatAyah.getText().toString();

                namaibu = etNamaIbu.getText().toString();
                ttlibu = etTtlIbu.getText().toString();
                notelpibu = etNoTelpIbu.getText().toString();
                pekerjaanibu = etPekerjaanIbu.getText().toString();
                alamatibu = etAlamatIbu.getText().toString();
                nokip = etNoKIP.getText().toString();

                //spinner
                tingkat = etTingkat.getSelectedItem().toString();

                tgldaftar = etTglDaftar.getText().toString();

                data(kode, ta, nama, tempatlahir, tanggallahir, jenis, nikakte, agama, suku, anakke, namaayah, ttlayah, notelpayah, pekerjaanayah, alamatayah, namaibu, ttlibu, notelpibu, pekerjaanibu, alamatibu, nokip, tingkat, tgldaftar);


                break;
        }
    }

    private void data(String kode,String ta,String nama,String tempatlahir,String tanggallahir,String jenis,String nikakte,String agama,String suku,String anakke,String namaayah,String ttlayah,String notelpayah,String pekerjaanayah,String alamatayah,String namaibu,String ttlibu,String notelpibu,String pekerjaanibu,String alamatibu,String nokip,String tingkat,String tgldaftar) {
        apiInterface = ApiClient.getClient().create(ApiInterface.class);
        Call<Data> call = apiInterface.dataResponse(kode, ta, nama, tempatlahir, tanggallahir, jenis, nikakte, agama, suku, anakke, namaayah, ttlayah, notelpayah, pekerjaanayah, alamatayah, namaibu, ttlibu, notelpibu, pekerjaanibu, alamatibu, nokip, tingkat, tgldaftar);
        call.enqueue(new Callback<Data>() {
            @Override
            public void onResponse(Call<Data> call, Response<Data> response) {
                if(response.body() != null && response.isSuccessful() && response.body().isStatus()){
                    sessionManager = new SessionManager(DataActivity.this);
                    DataData dataData = response.body().getDataData();
                    sessionManager.createDataSession(dataData);

//                    Toast.makeText(DataActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(DataActivity.this);

                    alertDialogBuilder.setTitle("Submit Data pendaftaran sudah selesai");

                    alertDialogBuilder
                            .setMessage("Klik Ya untuk selesai Mendaftar!")
                            .setIcon(R.mipmap.ic_launcher)
                            .setCancelable(false)
                            .setPositiveButton("Ya",new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,int id) {

                                    Intent intent = new Intent(DataActivity.this, MainActivity.class);
                                    startActivity(intent);
                                    finish();
                                }
                            });
                    // membuat alert dialog dari builder
                    AlertDialog alertDialog = alertDialogBuilder.create();

                    // menampilkan alert dialog
                    alertDialog.show();


                } else {
                    Toast.makeText(DataActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Data> call, Throwable t) {
                Log.e("Error ", t.getLocalizedMessage());
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}