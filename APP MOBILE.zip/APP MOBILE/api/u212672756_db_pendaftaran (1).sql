-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Waktu pembuatan: 23 Jan 2024 pada 12.29
-- Versi server: 10.6.14-MariaDB-cll-lve
-- Versi PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u212672756_db_pendaftaran`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_pendaftaran`
--

CREATE TABLE `data_pendaftaran` (
  `kode_pendaftar` int(10) NOT NULL,
  `tahun_ajaran` varchar(20) NOT NULL,
  `nama_lengkap` varchar(25) NOT NULL,
  `tempat_lahir` varchar(50) NOT NULL,
  `tanggal_lahir` varchar(25) NOT NULL,
  `jenis_kelamin` varchar(10) NOT NULL,
  `no_nik` varchar(20) NOT NULL,
  `agama` varchar(20) NOT NULL,
  `suku` varchar(20) NOT NULL,
  `anak_ke` varchar(20) NOT NULL,
  `nama_ayah_kandung` varchar(20) NOT NULL,
  `ttl_ayah` varchar(50) NOT NULL,
  `no_telp_ayah` varchar(20) NOT NULL,
  `pekerjaan_ayah` varchar(20) NOT NULL,
  `alamat_ayah` varchar(50) NOT NULL,
  `nama_ibu_kandung` varchar(25) NOT NULL,
  `ttl_ibu` varchar(50) NOT NULL,
  `no_telp_ibu` varchar(20) NOT NULL,
  `pekerjaan_ibu` varchar(20) NOT NULL,
  `alamat_ibu` varchar(50) NOT NULL,
  `no_kip` varchar(20) NOT NULL,
  `tingkat_yang_dimasuki` varchar(20) NOT NULL,
  `tanggal_daftar` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data untuk tabel `data_pendaftaran`
--

INSERT INTO `data_pendaftaran` (`kode_pendaftar`, `tahun_ajaran`, `nama_lengkap`, `tempat_lahir`, `tanggal_lahir`, `jenis_kelamin`, `no_nik`, `agama`, `suku`, `anak_ke`, `nama_ayah_kandung`, `ttl_ayah`, `no_telp_ayah`, `pekerjaan_ayah`, `alamat_ayah`, `nama_ibu_kandung`, `ttl_ibu`, `no_telp_ibu`, `pekerjaan_ibu`, `alamat_ibu`, `no_kip`, `tingkat_yang_dimasuki`, `tanggal_daftar`) VALUES
(10, '2023', 'feri agus irawan', 'medan', '040892', 'lakilaki', '132', 'islam', 'jawa', '2', 'feri', '03923', '023492', 'negeri', 'medan', 'feri', '0393', '09932', 'wira', 'medan', '0293', 'sd', 'hari ini'),
(133, '2023', 'ggvvb', 'bb.  ', '28/12/2023', 'Perempuan', '899855', 'Buddha', 'Buddha', 'vvvhh', 'vvvv', 'yvvvb', '66999', 'gccb', 'gvbnbv', 'gvv n', 'gvbn', '6955', 'gghh', 'vv nn', '6699', 'SD', '25^^:;;,*&');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users_admin`
--

CREATE TABLE `users_admin` (
  `kode_pendaftar` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users_admin`
--

INSERT INTO `users_admin` (`kode_pendaftar`, `username`, `email`, `password`, `role`) VALUES
(0, 'admin', 'admin@gmail.com', '0192023a7bbd73250516f069df18b500', 1),
(130, 'denis', 'denis@gmail.com', '719f67e6e85b355b7cd048f82c2a9a09', 0),
(131, 'riski', 'riski@gmail.com', '2e2a3744e841a70c1a02730450651fcb', 0),
(132, 'miki', 'miki', '4839641470743161315c2daed44ff32c', 0),
(133, 'mel', 'mel', '0ef174fc614c8d61e2d63329ef7f46c0', 0),
(135, 'uti', 'uti@gmail.com', '7f8c9288a19233e2fa2f8dc25ca0d047', 0);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `data_pendaftaran`
--
ALTER TABLE `data_pendaftaran`
  ADD PRIMARY KEY (`kode_pendaftar`);

--
-- Indeks untuk tabel `users_admin`
--
ALTER TABLE `users_admin`
  ADD PRIMARY KEY (`kode_pendaftar`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `data_pendaftaran`
--
ALTER TABLE `data_pendaftaran`
  MODIFY `kode_pendaftar` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=134;

--
-- AUTO_INCREMENT untuk tabel `users_admin`
--
ALTER TABLE `users_admin`
  MODIFY `kode_pendaftar` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=136;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
