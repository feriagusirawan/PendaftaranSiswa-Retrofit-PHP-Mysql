<?php

$connection = null;

try{
    //Config
    $host = "localhost";
    $username = "u212672756_feri";
    $password = "Atreyu04synyster";
    $dbname = "u212672756_db_pendaftaran";

    //Connect
    $database = "mysql:dbname=$dbname;host=$host";
    $connection = new PDO($database, $username, $password);
    $connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

} catch (PDOException $e){
    echo "Error ! " . $e->getMessage();
    die;
}

?>