<?php
session_start();
include 'connection.php';

if($_POST){
    //data pendaftar
    // $id_pendaftar = filter_input(INPUT_POST, 'id_pendaftar', FILTER_SANITIZE_STRING);

    $kode_pendaftar = filter_input(INPUT_POST, 'kode_pendaftar', FILTER_SANITIZE_STRING);
     $tahun_ajaran = filter_input(INPUT_POST, 'tahun_ajaran', FILTER_SANITIZE_STRING); 
     $nama_lengkap = filter_input(INPUT_POST, 'nama_lengkap', FILTER_SANITIZE_STRING);
     $tempat_lahir = filter_input(INPUT_POST, 'tempat_lahir', FILTER_SANITIZE_STRING);
     $tanggal_lahir = filter_input(INPUT_POST, 'tanggal_lahir', FILTER_SANITIZE_STRING);
     $jenis_kelamin = filter_input(INPUT_POST, 'jenis_kelamin', FILTER_SANITIZE_STRING);
     $no_nik = filter_input(INPUT_POST, 'no_nik', FILTER_SANITIZE_STRING);
     $agama = filter_input(INPUT_POST, 'agama', FILTER_SANITIZE_STRING);
     $suku = filter_input(INPUT_POST, 'suku', FILTER_SANITIZE_STRING);
     $anak_ke = filter_input(INPUT_POST, 'anak_ke', FILTER_SANITIZE_STRING);
     $nama_ayah_kandung = filter_input(INPUT_POST, 'nama_ayah_kandung', FILTER_SANITIZE_STRING);
     $ttl_ayah = filter_input(INPUT_POST, 'ttl_ayah', FILTER_SANITIZE_STRING);
     $no_telp_ayah = filter_input(INPUT_POST, 'no_telp_ayah', FILTER_SANITIZE_STRING);
     $pekerjaan_ayah = filter_input(INPUT_POST, 'pekerjaan_ayah', FILTER_SANITIZE_STRING);
     $alamat_ayah = filter_input(INPUT_POST, 'alamat_ayah', FILTER_SANITIZE_STRING);
        $nama_ibu_kandung = filter_input(INPUT_POST, 'nama_ibu_kandung', FILTER_SANITIZE_STRING);
        $ttl_ibu = filter_input(INPUT_POST, 'ttl_ibu', FILTER_SANITIZE_STRING);
        $no_telp_ibu = filter_input(INPUT_POST, 'no_telp_ibu', FILTER_SANITIZE_STRING);
        $pekerjaan_ibu = filter_input(INPUT_POST, 'pekerjaan_ibu', FILTER_SANITIZE_STRING);
        $alamat_ibu = filter_input(INPUT_POST, 'alamat_ibu', FILTER_SANITIZE_STRING);
        $no_kip = filter_input(INPUT_POST, 'no_kip', FILTER_SANITIZE_STRING);
        $tingkat_yang_dimasuki = filter_input(INPUT_POST, 'tingkat_yang_dimasuki', FILTER_SANITIZE_STRING);
        $tanggal_daftar = filter_input(INPUT_POST, 'tanggal_daftar', FILTER_SANITIZE_STRING);

    $response = [];

    //Cek username didalam databse
    $userQuery = $connection->prepare("SELECT * FROM data_pendaftaran where kode_pendaftar = ?");
    $userQuery->execute(array($kode_pendaftar));

    // Cek username apakah ada tau tidak
    if($userQuery->rowCount() != 0){
        // Beri Response
        $response['status']= false;
        $response['message']='Sudah Terdaftar Lol';
    } else {
        $insertAccount = 'INSERT INTO data_pendaftaran (kode_pendaftar, tahun_ajaran, nama_lengkap, tempat_lahir, tanggal_lahir, jenis_kelamin, no_nik, agama, suku, anak_ke, nama_ayah_kandung, ttl_ayah, no_telp_ayah, pekerjaan_ayah, alamat_ayah, nama_ibu_kandung, ttl_ibu, no_telp_ibu,	pekerjaan_ibu, alamat_ibu, no_kip, tingkat_yang_dimasuki, tanggal_daftar) values (:kode_pendaftar, :tahun_ajaran,	:nama_lengkap, :tempat_lahir, :tanggal_lahir, :jenis_kelamin, :no_nik, :agama, :suku, :anak_ke,	:nama_ayah_kandung,	:ttl_ayah, :no_telp_ayah, :pekerjaan_ayah, :alamat_ayah, :nama_ibu_kandung, :ttl_ibu, :no_telp_ibu,	:pekerjaan_ibu,	:alamat_ibu, :no_kip, :tingkat_yang_dimasuki, :tanggal_daftar)';


        $statement = $connection->prepare($insertAccount);

        try{
            //Eksekusi statement db
            $statement->execute([

                ':kode_pendaftar' => $kode_pendaftar,
                ':tahun_ajaran' => $tahun_ajaran,	
                ':nama_lengkap' => $nama_lengkap,
                ':tempat_lahir' => $tempat_lahir,
                ':tanggal_lahir' => $tanggal_lahir, 
                ':jenis_kelamin' => $jenis_kelamin,
                ':no_nik' => $no_nik,
                ':agama' => $agama,
                ':suku' => $agama,
                ':anak_ke' => $anak_ke,
                ':nama_ayah_kandung' => $nama_ayah_kandung,
                ':ttl_ayah' => $ttl_ayah,
                ':no_telp_ayah' => $no_telp_ayah,
                ':pekerjaan_ayah' => $pekerjaan_ayah,
                ':alamat_ayah' => $alamat_ayah,
                ':nama_ibu_kandung' => $nama_ibu_kandung,
                ':ttl_ibu' => $ttl_ibu,
                ':no_telp_ibu' => $no_telp_ibu,
                ':pekerjaan_ibu' => $pekerjaan_ibu,
                ':alamat_ibu' => $alamat_ibu,
                ':no_kip' => $no_kip,
                ':tingkat_yang_dimasuki' => $tingkat_yang_dimasuki, 
                ':tanggal_daftar' => $tanggal_daftar

            ]);

            $userQuery1 = $connection->prepare("SELECT * FROM data_pendaftaran where kode_pendaftar = ?");
            $userQuery1->execute(array($kode_pendaftar));
            $query = $userQuery1->fetch();
            //Beri response
            $response['status']= true;
            $response['message']='Data Pendaftar berhasil dikirim';
            $response['data'] = [

                'kode_pendaftar' => $kode_pendaftar,
                'tahun_ajaran' => $tahun_ajaran,	
                'nama_lengkap' => $nama_lengkap,
                'tempat_lahir' => $tempat_lahir,
                'tanggal_lahir' => $tanggal_lahir, 
                'jenis_kelamin' => $jenis_kelamin,
                'no_nik' => $no_nik,
                'agama' => $agama,
                'suku' => $agama,
                'anak_ke' => $anak_ke,
                'nama_ayah_kandung' => $nama_ayah_kandung,
                'ttl_ayah' => $ttl_ayah,
                'no_telp_ayah' => $no_telp_ayah,
                'pekerjaan_ayah' => $pekerjaan_ayah,
                'alamat_ayah' => $alamat_ayah,
                'nama_ibu_kandung' => $nama_ibu_kandung,
                'ttl_ibu' => $ttl_ibu,
                'no_telp_ibu' => $no_telp_ibu,
                'pekerjaan_ibu' => $pekerjaan_ibu,
                'alamat_ibu' => $alamat_ibu,
                'no_kip' => $no_kip,
                'tingkat_yang_dimasuki' => $tingkat_yang_dimasuki, 
                'tanggal_daftar' => $tanggal_daftar

            ];
        } catch (Exception $e){
            die($e->getMessage());
        }

    }
    
    //Jadikan data JSON
    $json = json_encode($response, JSON_PRETTY_PRINT);

    //Print JSON
    echo $json;
}